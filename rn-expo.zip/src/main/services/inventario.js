import {inventario_url, clientecodigo} from '../config/rest_config'



export async function getInventario()
{

/*
export async function getInventario(){

    try{
        let inventario = await fetch(`${inventario_url}?${clientecodigo}`);

        let result= await inventario.json();
        inventario = null;
        return result.inventario;
    }

    

    catch(error){
        throw error;



    }



}*/

}