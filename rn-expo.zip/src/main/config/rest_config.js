export const inventario_url= 'dev.isburo.com:8080/CRISCOLJavaEnvironment/rest/getInventario'
export const clientecodigo = '12'