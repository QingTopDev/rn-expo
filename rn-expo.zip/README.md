# rn-expo
<h2>Install package</h2>
<h3>npm install</h3>
<br>
<h2>Run App</h2>
<h3>expo start</h3>
